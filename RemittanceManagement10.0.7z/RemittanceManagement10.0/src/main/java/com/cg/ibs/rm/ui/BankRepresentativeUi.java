package com.cg.ibs.rm.ui;

public enum BankRepresentativeUi {
	 	VIEWREQUESTS, EXIT
}
